#!/usr/bin/env python3
"""
Academic Research Hub - Google Scholar Only

Search academic papers via Google Scholar (web scraping).
No API key required.

Note: Google Scholar has rate limits. Use responsibly.
"""

import argparse
import json
import sys
import os
import time
import random
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional
from enum import Enum

try:
    from lxml import html
    import requests
except ImportError:
    print("Error: Requires lxml and requests", file=sys.stderr)
    print("Install with: pip install lxml requests", file=sys.stderr)
    sys.exit(1)


class OutputFormat(Enum):
    """Available output formats"""
    TEXT = "text"
    JSON = "json"
    BIBTEX = "bibtex"
    RIS = "ris"
    MARKDOWN = "markdown"


def search_google_scholar(
    query: str,
    max_results: int = 10,
    year: Optional[int] = None,
    start_year: Optional[int] = None,
    end_year: Optional[int] = None,
    sort_by: str = "relevance",
    include_citations: bool = True
) -> List[Dict[str, Any]]:
    """
    Search Google Scholar via web scraping.
    
    Args:
        query: Search query
        max_results: Maximum number of results
        year: Filter by specific year
        start_year: Start year for range
        end_year: End year for range
        sort_by: Sort by 'relevance' or 'date'
        include_citations: Include citation counts
    
    Returns:
        List of paper dictionaries
    """
    
    # Build Google Scholar URL
    base_url = "https://scholar.google.com/scholar"
    
    params = {
        "q": query,
        "hl": "zh-CN",  # Chinese interface
        "num": max_results,
    }
    
    # Add date filters
    if year:
        params["as_ylo"] = year
        params["as_yhi"] = year
    elif start_year or end_year:
        if start_year:
            params["as_ylo"] = start_year
        if end_year:
            params["as_yhi"] = end_year
    
    # Sort by date
    if sort_by == "date":
        params["scisbd"] = "1"
    
    # User agent rotation (basic anti-scraping)
    user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    ]
    
    headers = {
        "User-Agent": random.choice(user_agents),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    }
    
    try:
        response = requests.get(base_url, params=params, headers=headers, timeout=30)
        response.raise_for_status()
        
        # Check if blocked
        if "did not match any documents" in response.text:
            print(f"No results found for query: {query}", file=sys.stderr)
            return []
        
        if "unusual traffic" in response.text.lower():
            print("Warning: Google Scholar detected unusual traffic. Results may be limited.", file=sys.stderr)
        
        tree = html.fromstring(response.text)
        papers = []
        
        # Find all result divs
        result_divs = tree.xpath('//div[@class="gs_r gs_or gs_scl"]')
        
        for div in result_divs[:max_results]:
            try:
                # Extract title
                title_elem = div.xpath('.//h3[@class="gs_rt"]//a/text()')
                title = title_elem[0].strip() if title_elem else "No title"
                
                # Extract link
                link_elem = div.xpath('.//h3[@class="gs_rt"]//a/@href')
                link = link_elem[0] if link_elem else ""
                
                # Extract publication info (authors, journal, year)
                pub_info = div.xpath('.//div[@class="gs_a"]/text()')
                pub_text = pub_info[0].strip() if pub_info else ""
                
                # Parse authors
                authors = []
                if pub_text:
                    parts = pub_text.split("-")
                    if parts:
                        authors_str = parts[0].strip()
                        authors = [a.strip() for a in authors_str.split(",")]
                
                # Parse year
                year_match = None
                if pub_text:
                    import re
                    year_matches = re.findall(r'\b(19|20)\d{2}\b', pub_text)
                    if year_matches:
                        year_match = int(year_matches[-1])
                
                # Extract snippet/abstract
                snippet_elem = div.xpath('.//div[@class="gs_rs"]/text()')
                snippet = snippet_elem[0].strip() if snippet_elem else ""
                
                # Extract citation count
                citations = 0
                cite_link_elem = div.xpath('.//a[contains(text(), "Cited by")]/text()')
                if cite_link_elem:
                    cite_text = cite_link_elem[0]
                    cite_match = re.search(r'\d+', cite_text)
                    if cite_match:
                        citations = int(cite_match.group())
                
                # Extract versions
                versions = 0
                version_elem = div.xpath('.//a[contains(text(), "versions")]/text()')
                if version_elem:
                    version_match = re.search(r'\d+', version_elem[0])
                    if version_match:
                        versions = int(version_match.group())
                
                # Extract PDF link if available
                pdf_link = None
                pdf_elem = div.xpath('.//a[contains(@href, ".pdf")]/@href')
                if pdf_elem:
                    pdf_link = pdf_elem[0]
                
                papers.append({
                    "title": title,
                    "authors": authors,
                    "year": year_match,
                    "journal": "",  # Hard to extract from GS
                    "snippet": snippet,
                    "citations": citations,
                    "versions": versions,
                    "url": link,
                    "pdf_url": pdf_link,
                    "source": "google_scholar"
                })
                
            except Exception as e:
                print(f"Error parsing result: {e}", file=sys.stderr)
                continue
        
        # Rate limiting - be respectful
        time.sleep(random.uniform(1.0, 2.0))
        
        return papers
    
    except requests.exceptions.RequestException as e:
        print(f"Error fetching from Google Scholar: {e}", file=sys.stderr)
        return []
    except Exception as e:
        print(f"Error searching Google Scholar: {e}", file=sys.stderr)
        return []


# ============================================================================
# Output Formatting Functions
# ============================================================================

def format_text(papers: List[Dict[str, Any]]) -> str:
    """Format results as plain text"""
    if not papers:
        return "No results found."
    
    lines = [f"Google Scholar Search Results: {len(papers)} papers found\n"]
    
    for i, paper in enumerate(papers, 1):
        lines.append(f"\n{i}. {paper['title']}")
        
        if paper.get("authors"):
            authors = ", ".join(paper["authors"][:5])
            if len(paper["authors"]) > 5:
                authors += " et al."
            lines.append(f"   Authors: {authors}")
        
        if paper.get("year"):
            lines.append(f"   Year: {paper['year']}")
        
        lines.append(f"   Citations: {paper.get('citations', 0)}")
        
        if paper.get("snippet"):
            snippet = paper["snippet"][:300]
            if len(paper["snippet"]) > 300:
                snippet += "..."
            lines.append(f"   Abstract: {snippet}")
        
        if paper.get("url"):
            lines.append(f"   URL: {paper['url']}")
        
        if paper.get("pdf_url"):
            lines.append(f"   PDF: {paper['pdf_url']}")
    
    return "\n".join(lines)


def format_json_output(papers: List[Dict[str, Any]]) -> str:
    """Format results as JSON"""
    return json.dumps(papers, indent=2, ensure_ascii=False)


def format_bibtex(papers: List[Dict[str, Any]]) -> str:
    """Format results as BibTeX"""
    entries = []
    
    for paper in papers:
        # Generate citation key
        first_author = paper.get("authors", ["Unknown"])[0].split()[-1].lower() if paper.get("authors") else "unknown"
        year = str(paper.get("year", "0000"))
        title_word = paper.get("title", "").split()[0].lower().replace(":", "")
        key = f"{first_author}{year}{title_word}"
        
        # Build entry
        entry = f"@article{{{key},\n"
        entry += f"  title={{{paper.get('title', 'No title')}}},\n"
        
        if paper.get("authors"):
            authors = " and ".join(paper["authors"])
            entry += f"  author={{{authors}}},\n"
        
        entry += f"  year={{{year}}},\n"
        
        if paper.get("url"):
            entry += f"  url={{{paper['url']}}},\n"
        
        entry = entry.rstrip(",\n") + "\n}\n"
        entries.append(entry)
    
    return "\n".join(entries)


def format_ris(papers: List[Dict[str, Any]]) -> str:
    """Format results as RIS"""
    entries = []
    
    for paper in papers:
        entry = "TY  - JOUR\n"
        entry += f"TI  - {paper.get('title', 'No title')}\n"
        
        for author in paper.get("authors", []):
            entry += f"AU  - {author}\n"
        
        year = str(paper.get("year", "0000"))
        entry += f"PY  - {year}\n"
        
        if paper.get("snippet"):
            entry += f"AB  - {paper['snippet']}\n"
        
        if paper.get("url"):
            entry += f"UR  - {paper['url']}\n"
        
        entry += "ER  -\n\n"
        entries.append(entry)
    
    return "".join(entries)


def format_markdown(papers: List[Dict[str, Any]]) -> str:
    """Format results as Markdown"""
    if not papers:
        return "# Search Results\n\nNo results found."
    
    lines = [f"# Google Scholar Search Results: {len(papers)} papers found\n"]
    
    for i, paper in enumerate(papers, 1):
        lines.append(f"\n## {i}. {paper['title']}\n")
        
        if paper.get("authors"):
            authors = ", ".join(paper["authors"][:5])
            if len(paper["authors"]) > 5:
                authors += " et al."
            lines.append(f"**Authors:** {authors}\n")
        
        if paper.get("year"):
            lines.append(f"**Year:** {paper['year']}\n")
        
        lines.append(f"**Citations:** {paper.get('citations', 0)}\n")
        
        if paper.get("snippet"):
            lines.append(f"**Abstract:** {paper['snippet']}\n")
        
        if paper.get("url"):
            lines.append(f"**URL:** {paper['url']}\n")
        
        if paper.get("pdf_url"):
            lines.append(f"**PDF:** [Download]({paper['pdf_url']})\n")
    
    return "\n".join(lines)


def format_output(papers: List[Dict[str, Any]], format_type: OutputFormat) -> str:
    """Format results according to specified format"""
    if format_type == OutputFormat.JSON:
        return format_json_output(papers)
    elif format_type == OutputFormat.BIBTEX:
        return format_bibtex(papers)
    elif format_type == OutputFormat.RIS:
        return format_ris(papers)
    elif format_type == OutputFormat.MARKDOWN:
        return format_markdown(papers)
    else:  # TEXT
        return format_text(papers)


# ============================================================================
# Main Function
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Search academic papers via Google Scholar",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic search
  %(prog)s "machine learning"
  
  # Filter by year
  %(prog)s "deep learning" --year 2023
  
  # Year range
  %(prog)s "neural networks" --start-year 2020 --end-year 2024
  
  # Sort by date
  %(prog)s "transformers" --sort-by date
  
  # Save as JSON
  %(prog)s "AI ethics" --format json --output results.json
  
  # Generate BibTeX
  %(prog)s "quantum computing" --format bibtex --output refs.bib

Note: Google Scholar has rate limits. Use responsibly.
        """
    )
    
    # Required arguments
    parser.add_argument(
        "query",
        type=str,
        help="Search query"
    )
    
    # General options
    parser.add_argument(
        "-n", "--max-results",
        type=int,
        default=10,
        help="Maximum number of results (default: 10)"
    )
    
    parser.add_argument(
        "-f", "--format",
        type=str,
        choices=["text", "json", "bibtex", "ris", "markdown"],
        default="text",
        help="Output format (default: text)"
    )
    
    parser.add_argument(
        "-o", "--output",
        type=str,
        help="Save results to file"
    )
    
    parser.add_argument(
        "--sort-by",
        type=str,
        choices=["relevance", "date"],
        default="relevance",
        help="Sort results by (default: relevance)"
    )
    
    # Filtering options
    parser.add_argument(
        "--year",
        type=int,
        help="Filter by specific year"
    )
    
    parser.add_argument(
        "--start-year",
        type=int,
        help="Start year for range"
    )
    
    parser.add_argument(
        "--end-year",
        type=int,
        help="End year for range"
    )
    
    parser.add_argument(
        "--no-citations",
        action="store_true",
        help="Don't include citation counts"
    )
    
    args = parser.parse_args()
    
    # Perform search
    papers = search_google_scholar(
        query=args.query,
        max_results=args.max_results,
        year=args.year,
        start_year=args.start_year,
        end_year=args.end_year,
        sort_by=args.sort_by,
        include_citations=not args.no_citations
    )
    
    # Format output
    output_format = OutputFormat(args.format)
    formatted_output = format_output(papers, output_format)
    
    # Save or print results
    if args.output:
        try:
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(formatted_output)
            print(f"Results saved to: {args.output}", file=sys.stderr)
        except Exception as e:
            print(f"Error saving to file: {e}", file=sys.stderr)
            sys.exit(1)
    else:
        print(formatted_output)


if __name__ == "__main__":
    main()
