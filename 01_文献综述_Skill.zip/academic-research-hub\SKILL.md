---
name: academic-research-hub
description: "Use this skill when users need to search academic papers via Google Scholar. Triggers include: requests to 'find papers on', 'search research about', 'Google Scholar search', or any request involving academic literature search. No API key required. Use for literature reviews, bibliography generation, and research discovery across all academic disciplines."
license: Proprietary
---

# Academic Research Hub - Google Scholar Edition

Search academic papers via Google Scholar web scraping. **No API key required.**

⚠️ **Note:** Google Scholar has rate limits. Use responsibly with delays between searches.

**Installation:**
```bash
# Only requires lxml and requests
pip install lxml requests
```

---

## Quick Reference

| Task | Command |
|------|---------|
| Basic search | `python scripts/research.py "machine learning"` |
| Filter by year | `python scripts/research.py "deep learning" --year 2023` |
| Year range | `python scripts/research.py "AI" --start-year 2020 --end-year 2024` |
| Sort by date | `python scripts/research.py "transformers" --sort-by date` |
| Save as JSON | `python scripts/research.py "NLP" --format json --output results.json` |
| Generate BibTeX | `python scripts/research.py "quantum" --format bibtex --output refs.bib` |
| Save citations | `python scripts/research.py "neural nets" --format ris --output citations.ris` |

---

## Core Features

### 1. Google Scholar Search

Search across all academic disciplines via Google Scholar.

**Coverage:**
- All academic fields (humanities, social sciences, STEM)
- Conference papers, journal articles, theses, books
- Multi-language support

### 2. Citation Tracking

Get citation counts for each paper.

### 3. Multiple Output Formats

- **Text** - Human-readable format (default)
- **JSON** - Structured data for processing
- **BibTeX** - For LaTeX documents
- **RIS** - For reference managers (Zotero, Mendeley, EndNote)
- **Markdown** - For documentation

### 4. Metadata Retrieval

Get comprehensive metadata for each paper:
- Title, authors
- Publication year
- Citation count
- Abstract/snippet
- URL and PDF links (when available)

---

## Usage Examples

### Basic Search

```bash
python scripts/research.py "climate change"
```

### Filter by Year

```bash
# Specific year
python scripts/research.py "deep learning" --year 2023

# Year range
python scripts/research.py "AI ethics" --start-year 2020 --end-year 2024
```

### Sort by Date

```bash
# Most recent first
python scripts/research.py "large language models" --sort-by date
```

### Output Formats

```bash
# JSON for processing
python scripts/research.py "machine learning" --format json --output papers.json

# BibTeX for LaTeX
python scripts/research.py "neural networks" --format bibtex --output references.bib

# RIS for Zotero/Mendeley
python scripts/research.py "covid vaccine" --format ris --output citations.ris

# Markdown for documentation
python scripts/research.py "renewable energy" --format markdown --output report.md
```

### Limit Results

```bash
python scripts/research.py "quantum computing" --max-results 5
```

---

## Command-Line Options

```
positional arguments:
  query                 Search query

optional arguments:
  -h, --help            show this help message and exit
  -n MAX_RESULTS, --max-results MAX_RESULTS
                        Maximum number of results (default: 10)
  -f {text,json,bibtex,ris,markdown}, --format {text,json,bibtex,ris,markdown}
                        Output format (default: text)
  -o OUTPUT, --output OUTPUT
                        Save results to file
  --sort-by {relevance,date}
                        Sort results by (default: relevance)
  --year YEAR           Filter by specific year
  --start-year START_YEAR
                        Start year for range
  --end-year END_YEAR   End year for range
  --no-citations        Don't include citation counts
```

---

## Output Examples

### Text Format (Default)

```
Google Scholar Search Results: 10 papers found

1. Attention Is All You Need
   Authors: Vaswani A, Shazeer N, Parmar N, et al.
   Year: 2017
   Citations: 150000+
   Abstract: The dominant sequence transduction models are based on complex recurrent...
   URL: https://arxiv.org/abs/1706.03762
```

### JSON Format

```json
[
  {
    "title": "Attention Is All You Need",
    "authors": ["Vaswani A", "Shazeer N", "Parmar N"],
    "year": 2017,
    "citations": 150000,
    "snippet": "The dominant sequence transduction models...",
    "url": "https://arxiv.org/abs/1706.03762",
    "pdf_url": "https://arxiv.org/pdf/1706.03762.pdf",
    "source": "google_scholar"
  }
]
```

### BibTeX Format

```bibtex
@article{vaswani2017attention,
  title={Attention Is All You Need},
  author={Vaswani A and Shazeer N and Parmar N},
  year={2017},
  url={https://arxiv.org/abs/1706.03762}
}
```

---

## Rate Limiting

**Important:** Google Scholar monitors for automated queries.

**Best Practices:**
- Limit searches to 10-20 results per query
- Add 1-2 second delays between searches
- Don't run more than 50 searches per hour
- Use different queries rather than pagination

---

## ⏱️ 超时处理与重试机制（v1.0.1 新增）

**超时配置：**
- 单次检索超时时间：**5 分钟**
- 最大重试次数：**3 次**
- 重试间隔：**10 秒**

**重试策略：**
```
第 1 次失败 → 等待 10 秒 → 重试（减少结果数量）
第 2 次失败 → 等待 10 秒 → 重试（更换排序方式）
第 3 次失败 → 记录失败原因 → 向主人汇报 → 继续下一数据源
```

**常见失败原因：**
- "Unusual traffic detected" - Google 检测到异常流量
- 网络连接超时
- 解析 HTML 失败

**失败后处理：**
1. 记录失败原因和时间
2. 向主人汇报："Google Scholar 检索失败，原因：XXX，已重试 3 次"
3. 继续执行 OpenAlex 检索
4. 任务完成后建议主人稍后单独补做 Google Scholar 检索

---

## Integration with Literature Review Workflow

This skill is designed to work as part of a larger literature review pipeline:

1. **Search** → Use this skill to find papers via Google Scholar
2. **Store** → Save results to database for further analysis
3. **Analyze** → Process metadata, citations, and content
4. **Generate** → Create literature review documents

---

## Limitations

- **No full-text download** - Google Scholar only provides links
- **Rate limits** - Be respectful of Google's servers
- **Incomplete metadata** - Some fields may be missing
- **No abstract** - Only snippets available in some cases

For comprehensive literature reviews, combine with:
- **CNKI Scraper** - For Chinese academic papers
- **academic-research** - For OpenAlex database (broader coverage)

---

## Troubleshooting

### "No results found"
- Try different keywords
- Check your internet connection
- Google Scholar may be temporarily blocked

### "Unusual traffic detected"
- Wait 10-15 minutes before retrying
- Reduce search frequency
- Use smaller result sets

### Missing citation counts
- Some papers don't have citation data
- Try accessing via URL directly

---

**Version:** 1.0.0 (Google Scholar Only)  
**Author:** anisafifi  
**Modified:** Simplified for Google Scholar only
